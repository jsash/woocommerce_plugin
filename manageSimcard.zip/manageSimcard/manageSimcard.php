
<?php
/*
Plugin Name: simcard mangment
Plugin URI: https://test.com
Description: سیستم مدیریت فعال سازی سیم کارت ها از طریق وب سایت.
Version: 1.0.0
Author: عبدالعلی وزیری
Author URI: https://mehrp.ir
Text Domain: simcard-mangment
WC requires at least: 4.0.0
WC tested up to: 6.5.1
*/
defined( 'ABSPATH' ) || exit;
/**
 * Check if WooCommerce is active
 **/
  require 'theme-settings/options-panel.php';

function modiredev_admin_scripts($hook)
{
    if ($hook === 'toplevel_page_panel-settings') {
        wp_enqueue_media();

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('wp-color-picker-alpha', get_theme_file_uri('/js/wp-color-picker-alpha.min.js'),
            array('wp-color-picker'), '1.0', true);
    }

    wp_enqueue_script('js_admin_panel',
        get_theme_file_uri('/js/admin.js'),
        array('jquery'), '1.0', true);

}

add_action('admin_enqueue_scripts', 'modiredev_admin_scripts');

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	if ( ! class_exists( 'WC_myclass' ) ) {//check don not use class 
	//برای افزودن یک آیتم به منوی اصلی این یک تست است فقط
	   add_filter('wp_nav_menu_items','add_item_in_menu', 10, 2);
  // این تابع برای این است که یک آیتم به منوی اصلی اضافه کنیم
  function add_item_in_menu( $items, $args ) {
		if( $args->theme_location == 'primary')  {
			//$todaysdate = date('l jS F Y');
			$simitem = "مدیریت سیم کارت";
			//echo $itemPath;
			$items .=  '<li ><a href="#">' . $simitem .  '</a></li>';
			
		}
		return $items;
	}
	}
	}
	
	//Creating Page Programmatically after Plugin Activation
	define( 'PLUGIN_FILE_PATH', __FILE__ );
	register_activation_hook( PLUGIN_FILE_PATH, 'insert_page_on_activation' );

	function insert_page_on_activation() {
	  if ( ! current_user_can( 'activate_plugins' ) ) return;

		$page_slug = 'test-page-title'; // Slug of the Post
		$new_page = array(
			'post_type'     => 'page', 				// Post Type Slug eg: 'page', 'post'
			'post_title'    => 'سیستم سیم کارت من',	// Title of the Content
			'post_content'  => '<html><head></head><body><button >تست دکمه</button></body></html>',	// Content
			'post_status'   => 'publish',			// Post Status
			'post_author'   => 1,					// Post Author ID
			'post_name'     => $page_slug			// Slug of the Post
		);
		if (!get_page_by_path( $page_slug, OBJECT, 'page')) { // Check If Page Not Exits
			$new_page_id = wp_insert_post($new_page);
			
		if (!term_exists('header-nav', 'nav_menu')) {

    $menu = wp_insert_term('header nav', 'nav_menu', array('slug' => 'header-nav'));

    // Select this menu in the current theme
    update_option('theme_mods_'.get_current_theme(), array("nav_menu_locations" => array("primary" => $menu['term_id'])));

    // Insert new page
    $page = wp_insert_post(array('post_title' => 'Blog',
                                 'post_content' => '',
                                 'post_status' => 'publish',
                                 'post_type' => 'page'));

    // Insert new nav_menu_item
    $nav_item = wp_insert_post(array('post_title' => 'News',
                                     'post_content' => '',
                                     'post_status' => 'publish',
                                     'post_type' => 'nav_menu_item'));


    add_post_meta($nav_item, '_menu_item_type', 'post_type');
    add_post_meta($nav_item, '_menu_item_menu_item_parent', '0');
    add_post_meta($nav_item, '_menu_item_object_id', $new_page);
    add_post_meta($nav_item, '_menu_item_object', 'page');
    add_post_meta($nav_item, '_menu_item_target', '');
    add_post_meta($nav_item, '_menu_item_classes', 'a:1:{i:0;s:0:"";}');
    add_post_meta($nav_item, '_menu_item_xfn', '');
    add_post_meta($nav_item, '_menu_item_url', '');

    wp_set_object_terms($nav_item, 'header-nav', 'nav_menu');
		}
		}
	}
/*
	/******************************
	load_plugin_textdomain( 'simcard-mangment', false, dirname( plugin_basename( __FILE__ ) ) . '/' );
	$itemPath = plugins_url().'/webpages/test.php';// define my variables
class WC_myclass {
  public function __construct() {
	// قبل از شامل شدن توابع تمپلیت های ووکامرس صدا میشود
    add_action( 'init', array( $this, 'include_template_functions' ), 20 );
 
	// بعد از پایان بارگذاری ووکامرس صدا میشود
    add_action( 'woocommerce_init', array( $this, 'woocommerce_loaded' ) );
	
	// بعد از بارگذاری همه افزونه ها صدا میشود
    add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ) );
	
	
 
	// چک میکند که کاربر فعلی مدیر سیستم باشد
    if ( is_admin() ) {
      // ...
    }
 
	// بررسی میکند که سایت روی اس اس ال مورد دسترسی قرار گرفته باشد
    if ( is_ssl() ) {
      // ...
    }
 
	// موارد دیگری که در زمان ایجاد یک نمونه از کلاس افزونه میبایست انجام شود را میتوانید اینجا در کانستراکتور انجام دهید
  }
 
  /**
   * توابع موجود در فایل های 
   * woocommerce/woocommerce-template.php
   * را میتوانیم با توابع خودمان جایگزین کنیم
   */
  //public function include_template_functions() {
    //include( 'woocommerce-template.php' );
  //}
 
  /**
   * در اینجا هر کاری را که برای انجام شدن نیازمند بارگذاری ووکامرس است انجام میدهیم.
   * مثلا شاید نیاز به دسترسی به
   * $woocommerce
   * داشته باشید
   */
  //public function woocommerce_loaded() {
    // ...
  //}
 
  /**
   * کارهایی که نیازمند بارگذاری کامل افزونه هاست را در اینجا انجام میدهیم.
   */
  //public function plugins_loaded() {
    // ...
	
  //}
  //public function test(){
	 // echo "این یک تست است";
  //}
 
//}
 
// از کلاس افزونه یک نمونه ایجاد میکنیم و آن را به گلوبال ها اضافه میکنیم
 
   // $GLOBALS['WC_myclass'] = new WC_myclass();
	//$WC_myclass = new WC_myclass();
	//$WC_myclass -> test();
	//$GLOBALS['WC_myclass'] -> test();

?>


