﻿<?php
require get_template_directory() . '/theme-settings/options-panel.php';

function modiredev_admin_scripts($hook)
{
    if ($hook === 'toplevel_page_panel-settings') {
        wp_enqueue_media();

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('wp-color-picker-alpha', get_theme_file_uri('/js/wp-color-picker-alpha.min.js'),
            array('wp-color-picker'), '1.0', true);
    }

    wp_enqueue_script('js_admin_panel',
        get_theme_file_uri('/js/admin.js'),
        array('jquery'), '1.0', true);

}

add_action('admin_enqueue_scripts', 'modiredev_admin_scripts');

