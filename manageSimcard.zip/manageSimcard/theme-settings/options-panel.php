<?php
if (!defined('ABSPATH')) {
    wp_die( 'شما نمی توانید به این صفحه دسترسی داشته باشید' );
}

function plugin_add_settings_page()
{
	//define new page to menu
    add_menu_page(
        'تنظیمات مدیریت سیم کارت',
        'مدیریت سیم کارت',
        'manage_options',
        'panel_settings',
        'modiredev_render_settings_panel',
        'dashicons-admin-customizer',
        62
    );
}

add_action('admin_menu', 'plugin_add_settings_page');


    

function modiredev_render_settings_panel()
{
    if (!current_user_can('manage_options')) {
        wp_die('کاربر غیرمجاز است');
    }

    if (isset($_POST['md_settings_save'])) {

        foreach ($_POST['panel_settings'] as $key => $value) {
            $_POST[$key] = sanitize_text_field($value);
        }

        if (isset($_POST['panel_settings']) && isset($_POST['md_settings_nonce'])) {
            if (!wp_verify_nonce($_POST['md_settings_nonce'], 'md_settings_nonce_action')) {
                wp_die('نانس مورد تایید نیست');
            }
            update_option('modiredev_panel_settings', $_POST['panel_settings'], 'yes');
            $message = 'تنظیمات ذخیره شد';
        }
    }

    $panel_settings_saved = get_option('modiredev_panel_settings');
    include 'options-panel-template.php';
}

function modiredev_wp_editor($content, $editor_name, $editor_id)
{
    $editor_settings = array(
        'textarea_name' => $editor_name,
        'media_buttons' => false,
        'textarea_rows' => 5,
        'quicktags' => false,
        'drag_drop_upload' => false,
        'tinymce' => array(
            'toolbar1' => 'bold,italic,underline,separator,alignleft,aligncenter,alignright,separator,link,unlink,undo,redo',
            'toolbar2' => '',
            'toolbar3' => '',
        ),
    );
    wp_editor($content, $editor_id, $editor_settings);
}