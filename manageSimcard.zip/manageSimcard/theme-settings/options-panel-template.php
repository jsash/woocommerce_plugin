<?php
if ( !defined('ABSPATH') ) {
    wp_die( 'شما نمی توانید به این صفحه دسترسی داشته باشید' );
}

if (!empty($message)) {
    ?>
    <div class="notice notice-success">
        <p><?php echo $message; ?></p>
    </div>
    <?php
}
?>
<div class="wrap">
    <div id="icon-edit" class="icon2 icon-32-posts-post"></div>

    <h2>پروفایل شبکه های اجتماعی</h2>
    <form action="" method="post">
        <?php wp_nonce_field('md_settings_nonce_action', 'md_settings_nonce') ?>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="twitter_url">توئیتر (Twitter):</label>
                </th>
                <td>
                    <input type="text"
                           id="twitter_url"
                           name="panel_settings[twitter_url]"
                           value="<?php echo esc_attr((isset($panel_settings_saved['twitter_url']) ? $panel_settings_saved['twitter_url'] : '')); ?>"
                           aria-required="true"
                           class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="facebook_url">فیسبوک (Facebook):</label>
                </th>
                <td>
                    <input type="text"
                           id="facebook_url"
                           name="panel_settings[facebook_url]"
                           value="<?php echo esc_attr((isset($panel_settings_saved['facebook_url']) ? $panel_settings_saved['facebook_url'] : '')); ?>"
                           aria-required="true"
                           class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="instagram_url">اینستاگرام (Instagram):</label>
                </th>
                <td>
                    <input type="text"
                           id="instagram_url"
                           name="panel_settings[instagram_url]"
                           value="<?php echo esc_attr((isset($panel_settings_saved['instagram_url']) ? $panel_settings_saved['instagram_url'] : '')); ?>"
                           aria-required="true"
                           class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="show_date">نمایش تاریخ در صفحه اصلی</label>
                </th>
                <td>
                    <input type="checkbox"
                           id="show_date"
                           name="panel_settings[show_date]"
                           value="true"
                        <?php echo isset($panel_settings_saved['show_date']) ? 'checked="checked"' : ''; ?>>
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>سایر تنظیمات</h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="email_url">آدرس ایمیل وب سایت:</label>
                </th>
                <td>
                    <input type="text"
                           id="email_url"
                           name="panel_settings[email_url]"
                           value="<?php echo esc_attr((isset($panel_settings_saved['email_url']) ? $panel_settings_saved['email_url'] : '')); ?>"
                           aria-required="true"
                           class="regular-text">
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>انتخاب رنگ</h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="bg_color">رنگ پس زمینه:</label>
                </th>
                <td>
                    <input type="text"
                           id="bg_color"
                           data-alpha="true"
                           name="panel_settings[bg_color]"
                           value="<?php echo esc_attr((isset($panel_settings_saved['bg_color']) ? $panel_settings_saved['bg_color'] : '')); ?>"
                           aria-required="true"
                           class="md-color-picker regular-text">
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>انتخاب تصویر</h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="md_image_upload_url">آدرس تصویر</label>
                </th>
                <td>
                    <input type="text" name="panel_settings[img_url]"
                           id="md_image_upload_url"
                           class="regular-text"
                           value="<?php echo esc_attr((isset($panel_settings_saved['img_url']) ? $panel_settings_saved['img_url'] : '')); ?>">
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <img id="md_image_upload_preview"
                         src="<?php echo $panel_settings_saved['img_url']; ?>);">
                </td>
            </tr>
            <tr>
                <td>
                    <input type="button"
                           class="button button-secondary md_image_upload"
                           value="افزودن تصویر">
                    <input type="button"
                           class="button button-secondary md_image_upload_remove"
                           value="حذف تصویر">
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>ویرایشگر وردپرس</h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="md_copyright">متن کپی رایت</label>
                </th>
                <td>
                    <?php
                    $copyright = isset($panel_settings_saved['md_copyright']) ? $panel_settings_saved['md_copyright'] : '';
                    modiredev_wp_editor($copyright, 'panel_settings[md_copyright]', 'md_copyright');
                    ?>
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>سلکت باکس</h2>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="md_default_category">دسته پیش فرض</label>
                </th>
                <td>
                    <?php
                    $categories = get_categories();
                    ?>
                    <select name="panel_settings[default_category]">
                        <option>یک دسته انتخاب کنید</option>
                        <?php
                        foreach ($categories as $category) {
                            ?>
                            <option value="<?php echo esc_attr($category->term_id); ?>"
                                <?php echo isset($panel_settings_saved['default_category']) &&
                                $panel_settings_saved['default_category'] == $category->term_id ? 'selected' : ''; ?>>
                                <?php echo $category->name; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>

        <hr>
        <h2>افزودن فیلد سفارشی</h2>
        <div class="wrap_custom_field">
            <table class="form-table">
                <tbody>
                <tr>
                    <th scope="row">
                        <label for="custom_field_label">برچسب</label>
                    </th>
                    <td>
                        <input type="text"
                               id="custom_field_label"
                               name="custom_field_label"
                               class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="custom_field_name">نام(یکتا با حروف انگلیسی)</label>
                    </th>
                    <td>
                        <input type="text"
                               id="custom_field_name"
                               name="custom_field_name"
                               class="regular-text text-left">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="custom_field_value">مقدار</label>
                    </th>
                    <td>
                        <input type="text"
                               id="custom_field_value"
                               name="custom_field_value"
                               class="regular-text">
                    </td>
                </tr>
                <tr>
                    <td>

                    </td>
                    <td>
                        <button class="button button-secondary" id="add-custom-field">افزودن فیلد</button>
                    </td>
                </tr>
                </tbody>
            </table>
            <table class="form-table custom-field-list">
                <tr>
                    <td>برچسب فیلد</td>
                    <td>نام فیلد</td>
                    <td>مقدار فیلد</td>
                </tr>
                <?php
                if (isset($panel_settings_saved['custom_field'])) {
                    foreach ($panel_settings_saved['custom_field'] as $custom_field) {
                        ?>
                        <tr>
                            <td>
                                <input name="panel_settings[custom_field][<?php echo $custom_field['name']; ?>][label]"
                                       type="text"
                                       value='<?php echo $custom_field['label']; ?>'/>
                            </td>
                            <td>
                                <input name="panel_settings[custom_field][<?php echo $custom_field['name']; ?>][name]"
                                       type="text"
                                       class="text-left"
                                       value='<?php echo $custom_field['name']; ?>'/>
                            </td>
                            <td>
                                <input name="panel_settings[custom_field][<?php echo $custom_field['name']; ?>][value]"
                                       type="text"
                                       value='<?php echo $custom_field['value']; ?>'/>
                            </td>
                            <td>
                                <button class="remove-custom-field button button-secondary">حذف</button>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
        </div>

        <hr>
        <p class="submit">
            <input type="submit" name="md_settings_save" class="button button-primary"
                   value="ذخیره">
        </p>
    </form>

</div>