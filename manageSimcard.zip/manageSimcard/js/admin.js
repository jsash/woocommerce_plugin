﻿(function ($) {

    $( '.md-color-picker' ).wpColorPicker();

    let mediaUploader;
    $('body').on('click', '.md_image_upload', function (e) {

        e.preventDefault();

        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            multiple: false
        });

        mediaUploader.on('select', function () {
            let attachment;
            attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#md_image_upload_url').val(attachment.url);
            $('#md_image_upload_preview').attr('src', attachment.url);
        });

        mediaUploader.open();
    });

    $('body').on('click', '.md_image_upload_remove', function (e) {
        e.preventDefault();
        $('#md_image_upload_url').val("");
        $('#md_image_upload_preview').attr('src', '');
    });

    $('#add-custom-field').click(function (e) {
        e.preventDefault();
        let field_label = $('#custom_field_label').val().trim(),
            field_name = $('#custom_field_name').val().trim(),
            field_value = $('#custom_field_value').val().trim();

        if (field_label === "" || field_name === "" || field_value === "") {
            return;
        }

        $('.custom-field-list').append(
            '<tr>' +
            '<td><input name="panel_settings[custom_field][' + field_name + '][label]" type="text" value="' + field_label + '"/></td>' +
            '<td><input name="panel_settings[custom_field][' + field_name + '][name]" type="text" value="' + field_name + '"/></td>' +
            '<td><input name="panel_settings[custom_field][' + field_name + '][value]" type="text" value="' + field_value + '"/></td>' +
            '</tr>'
        );
    });

    $('.wrap').on('click', '.remove-custom-field', function (e) {
        e.preventDefault();
        if (confirm("آیا این رکورد حذف شود؟")) {
            $(this).closest('tr').remove();
        }
    });

})(jQuery);
